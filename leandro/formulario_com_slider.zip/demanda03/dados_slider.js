// JavaScript source code
var Data = {
  R: {
    Min: 1,
    Media: 35.09,
    Moda: 3,
    Mediana: 29,
    Max: 91,
  },
};
