var dataRange = new Array();
var item = {};

item["Min"] = 0;
item["Max"] = 10;
item["CorFundo"] = "#64c832";
item["Texto"] = "Recente";
dataRange.push(item);

item = {};
item["Min"] = 10;
item["Max"] = 20;
item["CorFundo"] = "#fff900";
item["Texto"] = "Aten��o";
dataRange.push(item);

item = {};
item["Min"] = 20;
item["Max"] = 38;
item["CorFundo"] = "#ff8700";
item["Texto"] = "Em Risco";
dataRange.push(item);

item = {};
item["Min"] = 38;
item["Max"] = 64;
item["CorFundo"] = "#d10a00";
item["Texto"] = "Perdido";
dataRange.push(item);

item = {};
item["Min"] = 64;
item["Max"] = 91;
item["CorFundo"] = "#7b7b7b";
item["Texto"] = "Hibernando";
dataRange.push(item);// JavaScript source code
